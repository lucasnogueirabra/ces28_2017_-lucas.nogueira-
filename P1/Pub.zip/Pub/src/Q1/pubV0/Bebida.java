package Q1.pubV0;

import java.util.ArrayList;

public class Bebida {

	Bebida(int preco, String bebida, ArrayList<Ingredientes> ingredientes){
		set_ingredientes(new ArrayList<Ingredientes>());
		_ingredientes=ingredientes;
		set_bebida(bebida);
		
		
		//calcula preco da bebida preco da bebida 
		_preco=preco;
		if(ingredientes!=null)
		{
		for (int i=0; i<ingredientes.size();++i)
		{
			_preco=_preco+ingredientes.get(i).get_preco_ingrediente();
		}
		
		}
		
		
	}
	public String get_bebida() {
		return _bebida;
	}
	public void set_bebida(String _bebida) {
		this._bebida = _bebida;
	}
	public ArrayList<Ingredientes> get_ingredientes() {
		return _ingredientes;
	}
	public void set_ingredientes(ArrayList<Ingredientes> _ingredientes) {
		this._ingredientes = _ingredientes;
	}
	public int get_preco() {
		return _preco;
	}
	public void set_preco(int _preco) {
		this._preco = _preco;
	}
	
	public boolean equals(Object o)
	{
		if(o==this)
		{	return true;
		}
		if(!(o instanceof Bebida))
		{
			
			return false;
		}
		
		Bebida c= (Bebida) o;
		return this.get_preco()==c.get_preco()&&this.get_bebida().equals(c.get_bebida());
		
		
	}
	
	
	private String _bebida;
	private ArrayList<Ingredientes> _ingredientes;
	private int _preco;
	

}
