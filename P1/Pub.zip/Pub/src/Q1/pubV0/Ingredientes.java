package Q1.pubV0;

public class Ingredientes {
	private int _preco_ingrediente;

	Ingredientes(int preco_ingrediente){
		_preco_ingrediente=preco_ingrediente;
		
	}

	public int get_preco_ingrediente() {
		return _preco_ingrediente;
	}

	public void set_preco_ingrediente(int _preco_ingrediente) {
		this._preco_ingrediente = _preco_ingrediente;
	}
	
	
}
