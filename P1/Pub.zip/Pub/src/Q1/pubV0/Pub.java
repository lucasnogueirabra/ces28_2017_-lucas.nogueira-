package Q1.pubV0;

import java.util.ArrayList;

public class Pub {
	
	
	Pub(){	
		_Bebidas=new ArrayList<Bebida>();
		_Ingredientes=new  ArrayList<Ingredientes> ();
		
	}
	
	
	//Criando objetos j� existentes para que os testes funcionem 

	public void adicionar_bebidas_existentes()
	{		
		Ingredientes ingredient1=new Ingredientes(65);
		Ingredientes ingredient2=new Ingredientes(10);
		Ingredientes ingredient3=new Ingredientes(10);
		Ingredientes ingredient4=new Ingredientes(10);
		Ingredientes ingredient5=new Ingredientes(20);
		Ingredientes ingredient6=new Ingredientes(85);
		
		
		this.get_Ingredientes().add(ingredient1);
		this.get_Ingredientes().add(ingredient2);
		this.get_Ingredientes().add(ingredient3);
		this.get_Ingredientes().add(ingredient4);
		this.get_Ingredientes().add(ingredient5);
		this.get_Ingredientes().add(ingredient6);
		
		ArrayList<Ingredientes> _Ingredientes_GT=new ArrayList<Ingredientes> ();
		ArrayList<Ingredientes> _Ingredientes_BACARDI_SPECIAL=new ArrayList<Ingredientes> ();
		
		
		
		_Ingredientes_GT.add(ingredient4);
		_Ingredientes_GT.add(ingredient5);
		_Ingredientes_GT.add(ingredient6);
			
		_Ingredientes_BACARDI_SPECIAL.add(ingredient1);
		_Ingredientes_BACARDI_SPECIAL.add(ingredient2);
		_Ingredientes_BACARDI_SPECIAL.add(ingredient3);
		_Ingredientes_BACARDI_SPECIAL.add(ingredient6);
		
		
		ArrayList<Bebida> bebidas_existentes=new ArrayList<Bebida> ();
		
		
		
		Bebida ONE_BEER=new Bebida (74,"hansa",null);
		Bebida ONE_CIDER=new Bebida (103,"grans",null);
		Bebida GT=new Bebida (0,"gt",_Ingredientes_GT );
		Bebida A_PROPER_CIDER=new Bebida (110,"strongbow",null);
		Bebida BACARDI_SPECIAL=new Bebida (0,"bacardi_special",_Ingredientes_BACARDI_SPECIAL);
		
		bebidas_existentes.add(BACARDI_SPECIAL);
		bebidas_existentes.add(A_PROPER_CIDER);
		bebidas_existentes.add(GT);
		bebidas_existentes.add(ONE_CIDER);
		bebidas_existentes.add(ONE_BEER);
	
		this.set_Bebidas(bebidas_existentes);
	
		
		
	}
	
	private ArrayList<Bebida> _Bebidas;
	private ArrayList<Ingredientes> _Ingredientes;
    

    public int computeCost(String drink, boolean student, int amount) {
    	
    	//encontrar objeto
    	
    	adicionar_bebidas_existentes();
    	Bebida b = null;
    	for (int i=0; i<this.get_Bebidas().size();++i)
    	{
    		if(this.get_Bebidas().get(i).get_bebida().equals(drink))
    		{
    			
    			b=this.get_Bebidas().get(i);
    			break;
    			
    			
    		}
    		
    		
    	}
    	
    

    	
    	
        if (amount > 2 && (b.get_bebida().equals("gt")|| b.get_bebida().equals("bacardi_special"))) {
            throw new RuntimeException("Too many drinks, max 2.");
        }
        int price;

        if(b!=null)
        	price=b.get_preco();
       
        else {
            throw new RuntimeException("No such drink exists");
        }
        if (student && (b.get_bebida().equals("grans") ||b.get_bebida().equals("hansa") || b.get_bebida().equals("strongbow"))) {
            price = price - price/10;
        }
        return price*amount;
    }

    //one unit of rum
 

    //one unit of grenadine

	public ArrayList<Bebida> get_Bebidas() {
		return _Bebidas;
	}

	public void set_Bebidas(ArrayList<Bebida> _Bebidas) {
		this._Bebidas = _Bebidas;
	}



	public ArrayList<Ingredientes> get_Ingredientes() {
		return _Ingredientes;
	}



	public void set_Ingredientes(ArrayList<Ingredientes> _Ingredientes) {
		this._Ingredientes = _Ingredientes;
	}
}

