package Q3;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;
import static org.mockito.Mockito.*;

import Q3.TireMonitor.Alarm;
import Q3.TireMonitor.ISensor;

public class TestesQ3 {
	
	ISensor sensor;
	Alarm alarme;
	 	
	
	@Before 
	public void setup()
	{
		sensor=mock(ISensor.class);
		MockitoAnnotations.initMocks(this);
		alarme=new Alarm(sensor);
	}

	@Test
	public void testa_valor_100() {
		
		when(sensor.popNextPressurePsiValue()).thenReturn((double) 100);
		alarme.check();
		assertTrue(alarme.isAlarmOn());
		
	}
	
	
	@Test
	public void testa_valor_2() {
		
		when(sensor.popNextPressurePsiValue()).thenReturn((double) 2);
		alarme.check();
		assertTrue(alarme.isAlarmOn());
		
	}
	
	
	
	@Test
	public void testa_valor_18() {
		
		when(sensor.popNextPressurePsiValue()).thenReturn((double) 18);
		alarme.check();
		assertFalse(alarme.isAlarmOn());
		
	}
	
	
	

}
