package Q4;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;

import org.mockito.MockitoAnnotations;

import Q4.orig.ICalculadora;
import Q4.orig.ISistemaOperacional;
import Q4.orig.RelatorioDespesas;



public class testeQ4 {
	
	ICalculadora calculadora;
	ISistemaOperacional so;
	RelatorioDespesas relatorio;
	
	
	@Before 
	public void setup()
	{	
		MockitoAnnotations.initMocks(this);
		calculadora=mock(ICalculadora.class);
		so=mock(ISistemaOperacional.class);
		relatorio=new RelatorioDespesas(calculadora);
		when(calculadora.get_totalDespesa()).thenReturn((float) 100);
		
	}
	

	@Test
	public void testa_metodo_set_relatorio() {
	
		String relatorio1=relatorio.get_relatorio();
		assertTrue(relatorio1.equals("Relat�rio de Despesas\n Total das despesas:100.0"));
	}
	
	@Test
	public void testa_metodo_imprimir() {
		when(calculadora.get_totalDespesa()).thenReturn((float) 100);
		when(so.Imprimir(relatorio.get_relatorio())).thenReturn(true);		
		assertTrue(relatorio.imprimir_relatorio(so));
	}
	
	
	

}
