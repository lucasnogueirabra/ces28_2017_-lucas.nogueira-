package Q3.TireMonitor;

public interface ISensor {

	double popNextPressurePsiValue();

}
