package Q3.TireMonitor;


public class Alarm
{

    public Alarm(ISensor sensor) {
    	_sensor=sensor;
    	setpressure();
	}

	private final double LowPressureThreshold = 17;
    private final double HighPressureThreshold = 21;
    private ISensor _sensor;
    private boolean alarmOn = false;
    private double _psiPressureValue;

    public void  setpressure()
    {
    	_psiPressureValue=_sensor.popNextPressurePsiValue();	
    }
    
    public double  getpressure()
    {
    	setpressure();
    	return _psiPressureValue;
    }
    
    
    
    public void check()
    {
    	setpressure();
        if (_psiPressureValue < LowPressureThreshold || HighPressureThreshold < _psiPressureValue)
        {
            alarmOn = true;
        }
    }

    public boolean isAlarmOn()
    {
        return alarmOn; 
    }
}