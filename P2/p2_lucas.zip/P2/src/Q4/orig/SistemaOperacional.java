package Q4.orig;

public class SistemaOperacional implements ISistemaOperacional {
	private Impressora impressora;

	
	
	//teoricamente este metodo seria o responsavel por verificar a impressora correta e retona-la
	public Impressora getDriverImpressao() {
		return impressora=new Impressora();
	}

	public boolean Imprimir(String conteudo) {		
		return impressora.Imprimir(conteudo);
	}
	
	
}
