package Q4.orig;

import java.util.Iterator;

public class Calculadora implements ICalculadora {
	
	Calculadora(Iterator<Despesa> despesas)
	{
		_despesas=despesas;
		Settotal_despesa();
	
	}
	
	private Iterator<Despesa> _despesas;
	private float _totalDespesa;
	
	//calcula despesa total 
	public void Settotal_despesa() {
		 _totalDespesa = 0.0f;
		while (_despesas.hasNext()) {
			Despesa desp = _despesas.next();
			float despesa = desp.getDespesa();
			_totalDespesa+= despesa;
		}
	}
	
	public float get_totalDespesa()
	{
		Settotal_despesa();
		return _totalDespesa;
	}
		

}
 