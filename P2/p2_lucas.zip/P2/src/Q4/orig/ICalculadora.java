package Q4.orig;

public interface ICalculadora {

	float get_totalDespesa();
	void Settotal_despesa();
	
	
	

}
