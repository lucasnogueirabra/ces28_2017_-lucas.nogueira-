package Q4.orig;



// o USO DE PARAMETROS INTERFACE PERMITE QUE CLASSES QUE IMPLEMENTAM A INTERFACE SEJAM ALTERADAS SEM SE PREOCUPAR COM OS TESTES 


public class RelatorioDespesas {
	
	public RelatorioDespesas(ICalculadora calculadora)
	{
		_calculadora=calculadora;
		
	}
	private ICalculadora _calculadora;
	private float _totalDespesa;
	private String _relatorio;
	
	
	public void set_relatorio () {
		_relatorio = "Relat�rio de Despesas";
		_totalDespesa=_calculadora.get_totalDespesa();
		_relatorio+=("\n Total das despesas:" + _totalDespesa);
	}
	
	public String get_relatorio ()
	{	
		set_relatorio ();
		return _relatorio;
	}
	
	public boolean imprimir_relatorio(ISistemaOperacional so)

	{
		return so.Imprimir(_relatorio);
	}
	
	
}