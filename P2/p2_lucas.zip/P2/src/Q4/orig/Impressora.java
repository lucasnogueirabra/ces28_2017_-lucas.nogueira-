package Q4.orig;

public class Impressora {
	public boolean Imprimir(String conteudo) {
		if (conteudo==null) {
			return false;
		}
		else 
		{
			System.out.println(conteudo);
			return true;
		}
	}
}
