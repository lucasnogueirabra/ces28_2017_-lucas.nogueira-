package Q4.orig;

public interface ISistemaOperacional {

	boolean Imprimir(String _relatorio);

}
