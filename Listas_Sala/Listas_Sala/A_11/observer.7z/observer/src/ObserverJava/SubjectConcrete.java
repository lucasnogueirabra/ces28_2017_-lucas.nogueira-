package ObserverJava;

import java.util.Observable;

public class SubjectConcrete extends Observable{
	private String message;
	
	public void setState(String msg)
	{
		message = msg;
		
		setChanged();
		notifyObservers();
	}
	
	public String getMessage()
	{
		return message;
	}
}
