package ObserverJava;

public class main {
	public static void main (String args[])
	{
		ObserverConcrete obs1 = new ObserverConcrete("obs1");
		ObserverConcrete obs2 = new ObserverConcrete("obs2");
		SubjectConcrete sbj = new SubjectConcrete();
		
		sbj.addObserver(obs1);
		sbj.addObserver(obs2);
		
		System.out.println("Gerar primeiro evento");
		System.out.println("---------------------");
		
		sbj.setState(">>>Ol�, como vai?");

		System.out.println("---------------------");
		
		sbj.deleteObserver(obs1);
		
		System.out.println("");
		System.out.println("Gerar segundo evento");
		System.out.println("---------------------");
		
		sbj.setState(">>>Por aqui vai tudo bem!");
	}
}
