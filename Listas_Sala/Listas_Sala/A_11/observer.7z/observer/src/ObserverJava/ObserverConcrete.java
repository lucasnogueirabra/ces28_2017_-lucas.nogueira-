package ObserverJava;

import java.util.Observable;
import java.util.Observer;

public class ObserverConcrete implements Observer{
	private String _message;
	private String _id;
	
	public ObserverConcrete(String id)
	{
		_id = id;
	}
	
	@Override
	public void update(Observable subject, Object arg1)
	{
		System.out.println(_id+" notificado");
		if(subject instanceof SubjectConcrete)
		{
			SubjectConcrete sbj = (SubjectConcrete) subject;
			_message = sbj.getMessage();
			System.out.println(_message);
		}
	}
}
