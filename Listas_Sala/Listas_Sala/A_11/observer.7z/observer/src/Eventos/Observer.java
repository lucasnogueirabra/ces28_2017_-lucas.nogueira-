package Eventos;

public class Observer {
	
	public void getMessage(String message)
	{
		System.out.println(this+" "+message);
	}
	
}
