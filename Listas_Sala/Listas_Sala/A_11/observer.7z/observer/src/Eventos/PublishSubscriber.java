package Eventos;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class PublishSubscriber {
	
	public List<Observer> _listObservers;
	
	public PublishSubscriber()
	{
		_listObservers = new ArrayList<Observer>();
	}
	
	public void attachObs(Observer obs)
	{
		_listObservers.add(obs);
	}
	
	public void dettachObs(Observer obs)
	{
		_listObservers.remove(obs);
	}
	
	
	public void getMessage(String message)
	{
		Iterator<Observer> _listIterator = _listObservers.iterator();
		while(_listIterator.hasNext())
		{
			_listIterator.next().getMessage(message);
		}
	}
	
}
