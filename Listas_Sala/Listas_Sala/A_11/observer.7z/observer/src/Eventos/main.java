package Eventos;

public class main {
	public static void main(String args[])
	{
		PublishSubscriber PB = new PublishSubscriber();
		
		Subject sub1 = new Subject(); 
		Subject sub2 = new Subject();
		
		Observer obs1 = new Observer(); 
		Observer obs2 = new Observer(); 
		
		sub1.attachPB(PB);
		sub2.attachPB(PB);
		
		PB.attachObs(obs1);
		PB.attachObs(obs2);
		
		
		// agora fa�a um demo de comunica��o:
		sub1.setValue("msg do sub1");  // PB observa sub1 e recebe a mensagem.
		/* nesse momento PB repassa a mensagem para obs1 e obs2, que ao receber imprimem a mensagem. Aparece na tela:
		 obs1: recebi �msg do sub1�
		 obs2: recebi �msg do sub1�
		*/

		// analogamente, agora sub2 � mudado
		sub2.setValue("msg do sub2");

	}
}
