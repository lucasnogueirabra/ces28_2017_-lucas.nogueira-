package Eventos;


public class Subject {
	private String _value;
	private PublishSubscriber _PB;
	
	public void attachPB(PublishSubscriber PB)
	{
		_PB = PB;
	}
	
	public void dettachPB(PublishSubscriber PB)
	{
		_PB = null;
	}
	
	public void setValue(String value)
	{
		if (!value.equals(_value))
		{
			_value = value;
			notifyPB();
		}
	}
	
	private void notifyPB()
	{
		if(_PB != null)
		{
			_PB.getMessage(_value);
		}
	}
}
