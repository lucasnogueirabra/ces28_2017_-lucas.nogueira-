package aula11;

public class SO_SistemaCliente extends Observador{
	
	RN_Usuario _usuario;
	IU_TelaConversa _tela;
	String _msg;
	
	
	SO_SistemaCliente ()
	{ 
		_usuario= new RN_Usuario();
		_tela= new IU_TelaConversa(_usuario);
	}


	@Override
	public void update() {
		_msg=_usuario.getstate();
		System.out.println(_msg);
		
	}
	

}
