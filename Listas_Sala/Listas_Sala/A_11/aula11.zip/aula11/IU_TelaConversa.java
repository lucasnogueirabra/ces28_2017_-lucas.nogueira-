package aula11;

public class IU_TelaConversa extends Observador{
	
	String _msg;
	RN_Usuario _usuario;
	
	
	IU_TelaConversa(RN_Usuario usuario)
	{
		_usuario=usuario;
	}
	
	public void update()
	{
		
		_msg=_usuario.getstate();
		System.out.println(_msg);
	}
	
	
	
}
