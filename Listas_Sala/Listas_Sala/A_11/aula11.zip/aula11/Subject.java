package aula11;

import java.util.ArrayList;
import java.util.List;

public abstract class Subject {
	
	List<Observador> observadores = new ArrayList<Observador>();
	
	public void attach(Observador obs)
	{ 
		observadores.add(obs);
	}
	
	public void dettach(Observador obj)
	{		
		observadores.remove(obj);
	}
	
	public void Notify()
	{
		
		for (int i=0; i<observadores.size();++i)
		{
			observadores.get(i).update();
			
		}
		
	}

}
