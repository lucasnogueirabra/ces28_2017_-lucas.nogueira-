package aula11;

public abstract class Observador {

	
	public abstract void update();
}
