package aula11;

public class RN_Usuario extends Subject {
	
	private String _msg1;

	public void setstate(String msg1)
	{
		_msg1=msg1;

	}
	
	public String getstate()
	{
		return _msg1;
		
	}


}
