package aula11;

public class Main {

	public static void main(String[] args) {
		
		RN_Usuario usuario = new RN_Usuario();
		SO_SistemaCliente sc=new SO_SistemaCliente();
		IU_TelaConversa tc= new IU_TelaConversa(usuario);

		usuario.attach(tc);
		usuario.setstate("Ol�, como vai?");
		usuario.attach(sc);
		usuario.setstate("Ol�, como vai?");
		usuario.Notify();
		usuario.dettach(sc);
		usuario.setstate("Por aqui vai tudo bem!");
		tc.update();
	}

}
